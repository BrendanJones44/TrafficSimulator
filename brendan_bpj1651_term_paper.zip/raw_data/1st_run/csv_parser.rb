require 'CSV'

csv = CSV.read(File.open("east_data.csv"))
csv.each do |row|
  
end